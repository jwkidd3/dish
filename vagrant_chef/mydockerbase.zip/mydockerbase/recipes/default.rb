apt_update

apt_package 'apt-transport-https'
apt_package 'ca-certificates'
apt_package 'curl'
apt_package 'software-properties-common'

execute 'addkey' do
  command 'curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -'
end 

execute 'aptkey' do
  command 'sudo apt-key fingerprint 0EBFCD88'
end

execute 'debpkg' do
  command 'sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"'
end

execute 'update' do
  command 'sudo apt-get update'
end

apt_package 'docker-ce'

execute 'usermod' do
 command "sudo usermod -aG docker #{node['accounts']['username']}"
end
