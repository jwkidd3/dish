# mydockerbase

TODO: Enter the cookbook description here.

